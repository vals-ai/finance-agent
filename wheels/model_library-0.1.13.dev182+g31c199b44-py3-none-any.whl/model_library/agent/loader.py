"""Load `Agent.run` output back from disk.

Read-side counterpart to `Agent._write_init_dir` / `Agent._write_turn_dir`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from model_library.agent.metadata import AgentTurn, ErrorTurn


def load_config(task_dir: Path) -> dict[str, Any]:
    """Load `turns/init/config.json` (`llm`, `agent_config`, `tools`).

    The `llm` section is `LLM.__rich_repr__()` serialized with `default=str`,
    so it's informational — not a round-trippable `LLMConfig`. `agent_config`
    and `tools` are clean Pydantic dumps.
    """
    with (task_dir / "turns" / "init" / "config.json").open() as file_handle:
        return json.load(file_handle)


def load_turns(task_dir: Path) -> list[AgentTurn | ErrorTurn]:
    """Load every turn from `turns/turn_NNN/` in order.

    `Agent.run` writes successful turns to `result.json` (AgentTurn) and failed
    turns to `error.json` (ErrorTurn). Dirs with neither are partial writes and
    are skipped silently. Invalid JSON and schema mismatches propagate.
    """
    turn_paths = sorted(p for p in (task_dir / "turns").glob("turn_*") if p.is_dir())

    turns: list[AgentTurn | ErrorTurn] = []
    for turn_path in turn_paths:
        result_path = turn_path / "result.json"
        error_path = turn_path / "error.json"
        if result_path.exists():
            turns.append(AgentTurn.model_validate_json(result_path.read_text()))
        elif error_path.exists():
            turns.append(ErrorTurn.model_validate_json(error_path.read_text()))

    return turns
