"""Post-hoc Docent ingestion from an on-disk agent output directory.

Reads `Agent.run`'s output (via `model_library.agent.loader`) and produces
a `docent.data_models.AgentRun`. Never calls Docent — the caller owns upload.

For live (runtime) ingestion during `Agent.run`, see `model_library.docent`.
Both paths share converters and emit identical messages; this module only
adds disk loading.

    model-library-ingest <task_dir> --out <json_path>
"""

from __future__ import annotations

import argparse
import sys
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from docent.data_models import AgentRun, Transcript
from docent.data_models.chat import AssistantMessage, ChatMessage

from model_library.agent.loader import load_config, load_turns
from model_library.agent.metadata import ErrorTurn
from model_library.docent import (
    extract_hook_injected_messages,
    query_result_to_docent_messages,
    tool_call_records_to_docent_messages,
)


def build_agent_run(
    task_dir: Path,
    *,
    extra_metadata: dict[str, Any] | None = None,
) -> AgentRun:
    """Build a Docent AgentRun from one task's on-disk output.

    Args:
        task_dir: Directory containing `turns/init/` and `turns/turn_NNN/`.
        extra_metadata: Fields merged into the run-level metadata.
    """
    turns = load_turns(task_dir)

    messages: list[ChatMessage] = []
    for turn_index, turn in enumerate(turns, start=1):
        if isinstance(turn, ErrorTurn):
            messages.append(AssistantMessage(content=f"[error: {turn.error.message}]"))
            continue

        messages.extend(extract_hook_injected_messages(turn.query_result.history))
        messages.extend(
            query_result_to_docent_messages(
                turn.query_result,
                metadata={"turn_index": turn_index, **turn.to_summary().model_dump()},
            )
        )
        messages.extend(tool_call_records_to_docent_messages(turn.tool_call_records))

    run_metadata: dict[str, Any] = {
        "total_turns": len(turns),
        "init_config": load_config(task_dir),
    }
    if extra_metadata:
        run_metadata.update(extra_metadata)

    return AgentRun(transcripts=[Transcript(messages=messages)], metadata=run_metadata)


def _main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Build a Docent AgentRun JSON from an Agent.run task directory.",
    )
    parser.add_argument(
        "task_dir",
        type=Path,
        help="Task directory containing turns/init/ and turns/turn_NNN/.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        required=True,
        help="Path where the AgentRun JSON will be written.",
    )
    args = parser.parse_args(argv)

    run = build_agent_run(args.task_dir)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(run.model_dump_json())
    print(
        f"wrote AgentRun with {len(run.transcripts[0].messages)} messages to {args.out}",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
