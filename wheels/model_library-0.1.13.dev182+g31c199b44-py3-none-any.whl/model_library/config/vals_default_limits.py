from model_library.base.output import RateLimit

from functools import cache

vals_default_rate_limits: dict[str, dict[str, RateLimit | None]] = {
    "google": {
        "base": None,
        "flash-lite": RateLimit(
            token_limit=30_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None
        ),

        "gemini-3.1-pro": RateLimit(
            token_limit=8_000_000, request_limit=2_000, unix_timestamp=0.0, raw=None
        ),

        "gemini-3-flash": RateLimit(
            token_limit=20_000_000, request_limit=20_000, unix_timestamp=0.0, raw=None
        ),
        "gemini-3-pro": RateLimit(
            token_limit=10_000_000, request_limit=20_000, unix_timestamp=0.0, raw=None
        ),

        "gemini-2.5-pro": RateLimit(
            token_limit=8_000_000, request_limit=2_000, unix_timestamp=0.0, raw=None
        ),
        "gemini-2.5-flash": RateLimit(
            token_limit=20_000_000, request_limit=20_000, unix_timestamp=0.0, raw=None
        ),

        "gemini-2.0-flash-exp": RateLimit(
            token_limit=250_000, request_limit=10, unix_timestamp=0.0, raw=None
        ),
        "gemini-2.0-flash": RateLimit(
            token_limit=30_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None
        ),

        "gemma-4": RateLimit(
            token_limit=1_000_000, request_limit=300, unix_timestamp=0.0, raw=None
        ),
        "gemma-3": RateLimit(
            token_limit=15_000, request_limit=30, unix_timestamp=0.0, raw=None
        ),
    },
    "openai": {
        "base": None,

        "gpt-5.5-pro": RateLimit(
            token_limit=20_000_000, request_limit=8_000, unix_timestamp=0.0, raw=None
        ),
        "gpt-5.5": RateLimit(token_limit=5_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
        "summit-alpha": RateLimit(token_limit=5_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
        "macaroni-nano-alpha": RateLimit(token_limit=20_000_000, request_limit=8000, unix_timestamp=0.0, raw=None),
        "gpt-5.4-mini": RateLimit(token_limit=20_000_000, request_limit=8000, unix_timestamp=0.0, raw=None),

        "gpt-5.3-codex-preview": RateLimit(token_limit=250_000, request_limit=3_000, unix_timestamp=0.0, raw=None),
        "gpt-5.2": RateLimit(token_limit=40_000_000, request_limit=15_000, unix_timestamp=0.0, raw=None),
        "gpt-5.1": RateLimit(token_limit=40_000_000, request_limit=15_000, unix_timestamp=0.0, raw=None),
        "gpt-5-mini": RateLimit(token_limit=180_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "gpt-5-nano": RateLimit(token_limit=180_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "gpt-5": RateLimit(token_limit=40_000_000, request_limit=15_000, unix_timestamp=0.0, raw=None),

        "o4-mini": RateLimit(token_limit=150_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "o3-mini": RateLimit(token_limit=150_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "o3": RateLimit(token_limit=30_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
        "o1-pro": RateLimit(token_limit=30_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
        "o1": RateLimit(token_limit=30_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),

        "gpt-4.1-mini": RateLimit(token_limit=150_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "gpt-4.1-nano": RateLimit(token_limit=150_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "gpt-4.1": RateLimit(token_limit=30_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),

        "gpt-4o-mini": RateLimit(token_limit=150_000_000, request_limit=30_000, unix_timestamp=0.0, raw=None),
        "gpt-4o": RateLimit(token_limit=30_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),

        "gpt-4-turbo": RateLimit(token_limit=2_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
        "gpt-4": RateLimit(token_limit=1_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),

        "long-context": RateLimit(token_limit=10_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None),

        "gpt-3.5-turbo-instruct": RateLimit(token_limit=90_000, request_limit=3_500, unix_timestamp=0.0, raw=None),
        "gpt-3.5-turbo": RateLimit(token_limit=50_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),

        "text-embedding-": RateLimit(token_limit=10_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
    },
    "grok": {
        "base": None,
        "grok-experimental-0410-1p5m": RateLimit(
            token_limit=50_000_000, request_limit=3_000, unix_timestamp=0.0, raw=None
        ),
        "grok-experimental-0410-1p5m-exp-sa": RateLimit(
            token_limit=50_000_000, request_limit=3_000, unix_timestamp=0.0, raw=None
        ),
        "grok-4.20-beta-0309-reasoning": RateLimit(
            token_limit=4_000_000, request_limit=607, unix_timestamp=0.0, raw=None
        ),
        "grok-4-1-fast": RateLimit(
            token_limit=50_000_000, request_limit=3_000, unix_timestamp=0.0, raw=None
        ),
        "grok-4-fast-reasoning": RateLimit(
            token_limit=50_000_000, request_limit=3_000, unix_timestamp=0.0, raw=None
        ),
        "grok-4-fast-non-reasoning": RateLimit(
            token_limit=100_000_000, request_limit=4_800, unix_timestamp=0.0, raw=None
        ),
        "grok-4-0709": RateLimit(
            token_limit=2_000_000, request_limit=480, unix_timestamp=0.0, raw=None
        ),

        "grok-code-fast-1": RateLimit(
            token_limit=50_000_000, request_limit=1_200, unix_timestamp=0.0, raw=None
        ),
        "grok-3-mini": RateLimit(
            token_limit=None, request_limit=4_800, unix_timestamp=0.0, raw=None
        ),
        "grok-3": RateLimit(
            token_limit=None, request_limit=4_500, unix_timestamp=0.0, raw=None
        ),
    },
    "anthropic": {
        "base": None,
        "claude-nectarine-v5": RateLimit(
            token_limit=5_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "opus-4.5": RateLimit(
            token_limit_input=2_000_000, token_limit_output=400_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "opus-4-1": RateLimit(
            token_limit_input=5_000_000, token_limit_output=1_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "opus-4": RateLimit(
            token_limit_input=5_000_000, token_limit_output=1_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),

        "sonnet-4-5": RateLimit(
            token_limit_input=5_000_000, token_limit_output=1_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "sonnet-4": RateLimit(
            token_limit_input=5_000_000, token_limit_output=1_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "sonnet-3-7": RateLimit(
            token_limit_input=10_000_000, token_limit_output=2_000_000, request_limit=None, unix_timestamp=0.0, raw=None
        ),

        "haiku-4-5": RateLimit(
            token_limit_input=4_000_000, token_limit_output=800_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "haiku-3-5": RateLimit(
            token_limit_input=5_000_000, token_limit_output=1_000_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
        "haiku-3": RateLimit(
            token_limit_input=400_000, token_limit_output=80_000, request_limit=4_000, unix_timestamp=0.0, raw=None
        ),
    },
    "kimi": {
        "base": None,
        "kimi": RateLimit(token_limit=5_000_000, request_limit=5_000, unix_timestamp=0.0, raw=None),
    },
    "cohere": {
        "base": None,
        "command-a": RateLimit(request_limit=500, unix_timestamp=0.0, raw=None),
        "command-r-plus": RateLimit(request_limit=500, unix_timestamp=0.0, raw=None),
        "command-r": RateLimit(request_limit=500, unix_timestamp=0.0, raw=None),
        "command-r7b": RateLimit(request_limit=500, unix_timestamp=0.0, raw=None),
    },
    "minimax": {
        "base": None,
        "MiniMax-M2.7": RateLimit(token_limit=20_000_000, request_limit=500, unix_timestamp=0.0, raw=None),
    },
    "alibaba": {
        "base": None,
        "qwen3.6-max": RateLimit(token_limit=1_000_000, request_limit=600, unix_timestamp=0.0, raw=None),
        "qwen3.6-plus": RateLimit(token_limit=5_000_000, request_limit=15_000, unix_timestamp=0.0, raw=None),
    },
    "meta": {
        "base": None,
        # TODO: get real rate limits
        "muse_spark": RateLimit(token_limit=2_000_000, request_limit=10_000, unix_timestamp=0.0, raw=None),
    },
    "ai21labs": {
        "base": None,
        "jamba-large": RateLimit(request_limit=200, unix_timestamp=0.0, raw=None),
        "jamba-mini": RateLimit(request_limit=200, unix_timestamp=0.0, raw=None),
    },
}

@cache
def get_default_rate_limit(provider:str, model_name: str) -> RateLimit:
    provider_limits = vals_default_rate_limits[provider]

    for model_prefix, limit in provider_limits.items():
        if model_prefix in model_name:
            if limit is None:
                raise Exception(f"Missing limit for key {model_prefix}")
            return limit

    base = provider_limits["base"]
    if base:
        return base

    raise Exception(f"No default limit for {model_name}")
