"""
See deepseek data retention policy
https://cdn.deepseek.com/policies/en-US/deepseek-privacy-policy.html
"""

from typing import Any, Literal

from pydantic import SecretStr
from typing_extensions import override

from model_library import model_library_settings
from model_library.base import (
    DelegateOnly,
    LLMConfig,
)
from model_library.register_models import register_provider


@register_provider("deepseek")
class DeepSeekModel(DelegateOnly):
    def __init__(
        self,
        model_name: str,
        provider: Literal["deepseek"] = "deepseek",
        *,
        config: LLMConfig | None = None,
    ):
        super().__init__(model_name, provider, config=config)

        # https://api-docs.deepseek.com/
        config = config or LLMConfig()

        # BEGIN-INTERNAL
        # TODO: add custom_endpoint to YAML config schema instead of hardcoding
        # V4 pro is served via the pandora channel under the generic "model1" id.
        if model_name == "model1":
            config.custom_endpoint = (
                config.custom_endpoint or "https://api-pandora.deepseek.com/0ff0e7/v1"
            )
        # END-INTERNAL

        config.custom_endpoint = config.custom_endpoint or "https://api.deepseek.com/v1"
        config.custom_api_key = config.custom_api_key or SecretStr(
            model_library_settings.DEEPSEEK_API_KEY
        )

        self.init_delegate(
            config=config,
            delegate_provider="openai",
            use_completions=True,
        )

    @override
    def _get_extra_body(self) -> dict[str, Any]:
        # BEGIN-INTERNAL
        # V4 pro unified API requires an explicit thinking mode on every request.
        if self.model_name == "model1":
            mode = "enabled" if self.reasoning else "disabled"
            return {"thinking": {"type": mode}}
        # END-INTERNAL
        return {}
