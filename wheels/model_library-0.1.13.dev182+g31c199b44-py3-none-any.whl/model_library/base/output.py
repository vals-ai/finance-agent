"""
--- OUTPUT ---
"""

from enum import Enum
from collections.abc import Generator
from typing import Any, Mapping, Sequence, cast

from pydantic import BaseModel, Field, computed_field, field_validator
from typing_extensions import override

from model_library.base.input import InputItem, ToolCall
from model_library.base.utils import add_optional
from model_library.utils import PrettyModel


class FinishReason(str, Enum):
    """Standardized finish reasons across all providers."""

    STOP = "stop"
    """Model naturally finished generating."""

    STOP_SEQUENCE = "stop_sequence"
    """Model stopped due to a custom stop sequence."""

    MAX_TOKENS = "max_tokens"
    """Model stopped because it reached the maximum token limit."""

    CONTEXT_WINDOW_EXCEEDED = "context_window_exceeded"
    """Model stopped because the input exceeded the context window."""

    TOOL_CALLS = "tool_calls"
    """Model stopped to make one or more tool calls."""

    CONTENT_FILTER = "content_filter"
    """Model output was blocked by a content filter or safety policy."""

    GUARDRAIL = "guardrail"
    """Model output was blocked by a guardrail."""

    MALFORMED_TOOL_CALL = "malformed_tool_call"
    """Model attempted a tool call but it was malformed or unexpected."""

    ERROR = "error"
    """An error occurred during generation."""

    UNKNOWN = "unknown"
    """The finish reason is unknown or not recognized."""


class FinishReasonInfo(PrettyModel):
    reason: FinishReason
    raw: str | None


class Citation(PrettyModel):
    type: str | None = None
    title: str | None = None
    url: str | None = None
    start_index: int | None = None
    end_index: int | None = None
    file_id: str | None = None
    filename: str | None = None
    index: int | None = None
    container_id: str | None = None


class QueryResultExtras(PrettyModel):
    citations: list[Citation] = Field(default_factory=list)


class QueryResultCost(PrettyModel):
    """
    Cost information for a query
    Includes total cost and a structured breakdown.
    """

    input: float
    output: float
    reasoning: float | None = None
    cache_read: float | None = None
    cache_write: float | None = None
    total_override: float | None = None

    @computed_field
    @property
    def total(self) -> float:
        if self.total_override is not None:
            return self.total_override

        return sum(
            filter(
                None,
                [
                    self.input,
                    self.output,
                    self.reasoning,
                    self.cache_read,
                    self.cache_write,
                ],
            )
        )

    @computed_field
    @property
    def total_input(self) -> float:
        return sum(
            filter(
                None,
                [
                    self.input,
                    self.cache_read,
                    self.cache_write,
                ],
            )
        )

    @computed_field
    @property
    def total_output(self) -> float:
        return sum(
            filter(
                None,
                [
                    self.output,
                    self.reasoning,
                ],
            )
        )

    def __add__(self, other: "QueryResultCost") -> "QueryResultCost":
        return QueryResultCost(
            input=self.input + other.input,
            output=self.output + other.output,
            reasoning=add_optional(self.reasoning, other.reasoning),
            cache_read=add_optional(self.cache_read, other.cache_read),
            cache_write=add_optional(self.cache_write, other.cache_write),
            total_override=add_optional(self.total_override, other.total_override),
        )

    @override
    def __repr__(self):
        use_cents = self.total < 1

        def format_cost(value: float | None):
            if value is None:
                return None
            return f"{value * 100:.3f} cents" if use_cents else f"${value:.2f}"

        return (
            f"{format_cost(self.total)} "
            + f"(uncached input: {format_cost(self.input)} | output: {format_cost(self.output)} | reasoning: {format_cost(self.reasoning)} | cache_read: {format_cost(self.cache_read)} | cache_write: {format_cost(self.cache_write)})"
        )


class RateLimit(PrettyModel):
    """Rate limit information"""

    request_limit: int | None = None
    request_remaining: int | None = None

    token_limit: int | None = None
    token_limit_input: int | None = None
    token_limit_output: int | None = None

    token_remaining: int | None = None
    token_remaining_input: int | None = None
    token_remaining_output: int | None = None

    unix_timestamp: float
    raw: Any

    @computed_field
    @property
    def token_limit_total(self) -> int:
        if self.token_limit:
            return self.token_limit
        else:
            return (self.token_limit_input or 0) + (self.token_limit_output or 0)

    @computed_field
    @property
    def token_remaining_total(self) -> int:
        if self.token_remaining:
            return self.token_remaining
        else:
            return (self.token_remaining_input or 0) + (
                self.token_remaining_output or 0
            )

    @override
    def __rich_repr__(self) -> Generator[tuple[str, Any], None, None]:
        attrs = vars(self).copy()
        attrs.pop("raw", None)
        yield from attrs.items()


class QueryResultMetadata(PrettyModel):
    """Metadata for a query: token usage and timing"""

    cost: QueryResultCost | None = None  # set post query
    duration_seconds: float | None = None  # set post query; rounded to ms
    in_tokens: int = 0

    @field_validator("duration_seconds", mode="before")
    @classmethod
    def _round_duration(cls, v: float | None) -> float | None:
        return round(v, 3) if v is not None else None

    out_tokens: int = 0
    reasoning_tokens: int | None = None
    cache_read_tokens: int | None = None
    cache_write_tokens: int | None = None
    extra: dict[str, Any] = {}

    @property
    def default_duration_seconds(self) -> float:
        return self.duration_seconds or 0

    @computed_field
    @property
    def total_input_tokens(self) -> int:
        return sum(
            filter(
                None,
                [
                    self.in_tokens,
                    self.cache_read_tokens,
                    self.cache_write_tokens,
                ],
            )
        )

    @computed_field
    @property
    def total_output_tokens(self) -> int:
        return sum(
            filter(
                None,
                [
                    self.out_tokens,
                    self.reasoning_tokens,
                ],
            )
        )

    def __add__(self, other: "QueryResultMetadata") -> "QueryResultMetadata":
        return QueryResultMetadata(
            in_tokens=self.in_tokens + other.in_tokens,
            out_tokens=self.out_tokens + other.out_tokens,
            reasoning_tokens=cast(
                int | None, add_optional(self.reasoning_tokens, other.reasoning_tokens)
            ),
            cache_read_tokens=cast(
                int | None,
                add_optional(self.cache_read_tokens, other.cache_read_tokens),
            ),
            cache_write_tokens=cast(
                int | None,
                add_optional(self.cache_write_tokens, other.cache_write_tokens),
            ),
            duration_seconds=self.default_duration_seconds
            + other.default_duration_seconds,
            cost=cast(QueryResultCost | None, add_optional(self.cost, other.cost)),
        )


class QueryResult(PrettyModel):
    """
    Result of a query
    Contains the text, reasoning, metadata, tool calls, and history
    """

    output_text: str | None = None
    output_parsed: dict[str, Any] | BaseModel | None = None
    reasoning: str | None = None
    finish_reason: FinishReasonInfo = Field(
        default_factory=lambda: FinishReasonInfo(reason=FinishReason.UNKNOWN, raw=None)
    )
    metadata: QueryResultMetadata = Field(default_factory=QueryResultMetadata)
    tool_calls: list[ToolCall] = Field(default_factory=list)
    history: list[InputItem] = Field(default_factory=list)
    extras: QueryResultExtras = Field(default_factory=QueryResultExtras)
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def output_text_str(self) -> str:
        return self.output_text or ""

    @field_validator("reasoning", mode="before")
    def default_reasoning(cls, v: str | None):
        return None if not v else v  # make reasoning None if empty

    @property
    def search_results(self) -> Any | None:
        """Expose provider-supplied search metadata without additional processing."""
        raw_dict = cast(dict[str, Any], getattr(self, "raw", {}))
        raw_candidate = raw_dict.get("search_results")
        if raw_candidate is not None:
            return raw_candidate

        return _get_from_history(self.history, "search_results")

    @override
    def __rich_repr__(self):
        attrs = vars(self).copy()
        yield "output_text", attrs.pop("output_text", None)
        yield "reasoning", attrs.pop("reasoning", None)
        yield "metadata", attrs.pop("metadata", None)
        if self.tool_calls:
            yield "tool_calls", self.tool_calls


def _get_from_history(history: Sequence[InputItem], key: str) -> Any | None:
    for item in reversed(history):
        value = getattr(item, key, None)
        if value is not None:
            return value

        extra = getattr(item, "model_extra", None)
        if isinstance(extra, Mapping):
            value = cast(Mapping[str, Any], extra).get(key)
            if value is not None:
                return value

    return None
